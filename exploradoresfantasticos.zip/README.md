alexa-skill-exploradoresfantasticos

Exploradores Fantásticos es la skill de ejemplo de mi artículo en Medium - Creando una skill de Alexa usando Python
